# Person 2 — Candidate Generation

## Your responsibility
Find a manageable shortlist of items that could be recommended.

## Learn
- Popularity-based recommendations
- Candidate generation vs. ranking
- Why excluding items a user has already interacted with matters

## Files
- `baselines.py`: ranks items using interaction count and average rating.
- `candidate_generation.py`: produces a shortlist and excludes items already seen by the user.

## Try next
- Compare popularity ranking with average-rating ranking.
- Add a minimum-interaction threshold.
- Discuss cold-start users and items.
