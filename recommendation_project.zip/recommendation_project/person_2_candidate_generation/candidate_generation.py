"""Generate a shortlist of candidate items for a user."""
from pathlib import Path
import pandas as pd

DATA_PATH = Path(__file__).resolve().parents[1] / "data" / "dataset.csv"

def generate_candidates(user_id, top_n=10, path=DATA_PATH):
    df = pd.read_csv(path)
    seen = set(df.loc[df["user_id"] == user_id, "item_id"])
    candidates = (df.groupby("item_id")
                    .agg(interactions=("rating", "size"), mean_rating=("rating", "mean"))
                    .sort_values(["interactions", "mean_rating"], ascending=False))
    candidates = candidates.loc[~candidates.index.isin(seen)]
    return candidates.head(top_n).reset_index()

if __name__ == "__main__":
    print(generate_candidates(user_id=1))
