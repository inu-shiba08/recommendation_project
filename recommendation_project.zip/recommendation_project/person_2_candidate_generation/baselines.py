"""Simple baselines for comparison."""
from pathlib import Path
import pandas as pd

DATA_PATH = Path(__file__).resolve().parents[1] / "data" / "dataset.csv"

def popular_items(path=DATA_PATH, top_n=5):
    df = pd.read_csv(path)
    return (df.groupby("item_id")
              .agg(interactions=("rating", "size"), mean_rating=("rating", "mean"))
              .sort_values(["interactions", "mean_rating"], ascending=False)
              .head(top_n))

if __name__ == "__main__":
    print(popular_items())
