"""Clean and validate the recommendation dataset."""
from pathlib import Path
import pandas as pd

DATA_PATH = Path(__file__).resolve().parents[1] / "data" / "dataset.csv"

def clean_data(path=DATA_PATH):
    df = pd.read_csv(path)
    required = {"user_id", "item_id", "rating"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Dataset is missing required columns: {sorted(missing)}")
    df = df.drop_duplicates(subset=["user_id", "item_id"])
    df = df.dropna(subset=["user_id", "item_id", "rating"])
    return df

if __name__ == "__main__":
    cleaned = clean_data()
    print(f"Clean rows: {len(cleaned)}")
    print(cleaned.head())
