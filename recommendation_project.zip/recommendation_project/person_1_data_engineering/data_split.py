"""Create reproducible train/test splits."""
from sklearn.model_selection import train_test_split
from data_cleaning import clean_data

def split_data(test_size=0.2, random_state=42):
    df = clean_data()
    if len(df) < 2:
        raise ValueError("At least two rows are required to split the dataset.")
    return train_test_split(df, test_size=test_size, random_state=random_state)

if __name__ == "__main__":
    train, test = split_data()
    print(f"Train rows: {len(train)} | Test rows: {len(test)}")
