# Person 1 — Data Engineering

## Your responsibility
Prepare reliable data for the recommendation pipeline.

## Learn
- Rows, columns, data types, and missing values in pandas
- Duplicate records and why they can distort recommendations
- Train/test splits and data leakage
- Why a fixed random seed makes experiments reproducible

## Files
- `data_cleaning.py`: validates expected columns and removes invalid/duplicate rows.
- `data_split.py`: creates a reproducible train/test split.

## Try next
1. Inspect `data/dataset.csv`.
2. Add checks for valid rating ranges.
3. Record dataset row counts before and after cleaning.
