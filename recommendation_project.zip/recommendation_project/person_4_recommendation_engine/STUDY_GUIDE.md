# Person 4 — Recommendation Engine

## Your responsibility
Connect the recommendation stages and apply product/business constraints.

## Learn
- End-to-end recommendation pipeline
- Seen-item filtering
- Business rules and explainability
- How to return a stable, easy-to-consume output

## Files
- `recommender.py`: creates ranked recommendations for a user.
- `business_rules.py`: filters blocked items and optional minimum scores.

## Try next
- Add category diversity or a cap per category.
- Explain why each item was recommended.
- Test unknown user IDs and empty results.
