"""Combine candidate generation and ranking into recommendations."""
from pathlib import Path
import pandas as pd

DATA_PATH = Path(__file__).resolve().parents[1] / "data" / "dataset.csv"

def recommend(user_id, top_n=5, path=DATA_PATH):
    df = pd.read_csv(path)
    seen = set(df.loc[df["user_id"] == user_id, "item_id"])
    stats = df.groupby("item_id").agg(
        interaction_count=("rating", "size"),
        average_rating=("rating", "mean")
    ).reset_index()
    max_count = max(stats["interaction_count"].max(), 1)
    stats["score"] = stats["average_rating"] + 0.1 * stats["interaction_count"] / max_count
    stats = stats[~stats["item_id"].isin(seen)]
    return stats.sort_values("score", ascending=False).head(top_n)

if __name__ == "__main__":
    print(recommend(user_id=1))
