"""Apply simple business rules to recommendation results."""

def apply_rules(recommendations, blocked_items=None, min_score=None):
    result = recommendations.copy()
    if blocked_items:
        result = result[~result["item_id"].isin(blocked_items)]
    if min_score is not None and "score" in result.columns:
        result = result[result["score"] >= min_score]
    return result
