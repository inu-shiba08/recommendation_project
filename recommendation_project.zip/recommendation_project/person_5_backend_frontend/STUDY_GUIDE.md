# Person 5 — Backend and Frontend

## Your responsibility
Build a user interface and API around the recommendation engine.

## Suggested starter stack
- Backend: Python + FastAPI
- Frontend: HTML, CSS, and JavaScript
- API endpoint idea: `GET /recommendations/{user_id}`

## Workflow
1. Call the recommendation engine from the backend.
2. Return recommendations as JSON.
3. Display item IDs and scores in the frontend.
4. Handle loading, empty results, and errors.

## Try next
- Add a form to enter a user ID.
- Keep API and UI code separate.
- Never expose secrets in frontend code.
