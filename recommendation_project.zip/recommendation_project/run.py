"""Run the starter recommendation pipeline."""
import argparse
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "person_4_recommendation_engine"))
from recommender import recommend
from business_rules import apply_rules

def main():
    parser = argparse.ArgumentParser(description="Run the recommendation project.")
    parser.add_argument("--user-id", type=int, default=1, help="User ID to recommend items for")
    parser.add_argument("--top-n", type=int, default=5, help="Maximum recommendations")
    args = parser.parse_args()

    results = recommend(args.user_id, args.top_n)
    results = apply_rules(results)
    if results.empty:
        print(f"No unseen recommendations available for user {args.user_id}.")
    else:
        print(f"Recommendations for user {args.user_id}:")
        print(results.to_string(index=False))

if __name__ == "__main__":
    main()
