"""A simple, interpretable ranking score."""
from pathlib import Path
import pandas as pd

DATA_PATH = Path(__file__).resolve().parents[1] / "data" / "dataset.csv"

def rank_items(path=DATA_PATH):
    df = pd.read_csv(path)
    stats = df.groupby("item_id").agg(
        interaction_count=("rating", "size"),
        average_rating=("rating", "mean")
    ).reset_index()
    # Starter score: average rating with a small popularity contribution.
    max_count = max(stats["interaction_count"].max(), 1)
    stats["score"] = stats["average_rating"] + 0.1 * stats["interaction_count"] / max_count
    return stats.sort_values("score", ascending=False)

if __name__ == "__main__":
    print(rank_items())
