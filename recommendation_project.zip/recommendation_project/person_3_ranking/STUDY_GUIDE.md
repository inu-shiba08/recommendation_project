# Person 3 — Ranking

## Your responsibility
Score candidate items and evaluate recommendation quality.

## Learn
- Features and target variables
- Ranking scores and sorting
- Precision@K and train/test evaluation
- Why offline metrics are only a proxy for user satisfaction

## Files
- `features.py`: computes item-level statistics.
- `ranking_model.py`: starter interpretable scoring formula.
- `evaluation.py`: includes a basic Precision@K helper.

## Try next
- Compare the ranking score with popularity-only results.
- Add Recall@K.
- Evaluate only against held-out interactions, not training data.
