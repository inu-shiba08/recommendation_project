"""Build basic item features for ranking candidates."""
from pathlib import Path
import pandas as pd

DATA_PATH = Path(__file__).resolve().parents[1] / "data" / "dataset.csv"

def build_item_features(path=DATA_PATH):
    df = pd.read_csv(path)
    return (df.groupby("item_id")
              .agg(interaction_count=("rating", "size"),
                   average_rating=("rating", "mean"))
              .reset_index())

if __name__ == "__main__":
    print(build_item_features())
