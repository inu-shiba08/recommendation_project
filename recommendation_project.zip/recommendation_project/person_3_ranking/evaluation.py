"""Basic offline evaluation helpers."""
def precision_at_k(recommended, relevant, k=5):
    if k <= 0:
        raise ValueError("k must be positive")
    recommended_k = list(recommended)[:k]
    if not recommended_k:
        return 0.0
    hits = sum(1 for item in recommended_k if item in set(relevant))
    return hits / len(recommended_k)

if __name__ == "__main__":
    print("Example Precision@3:", precision_at_k([10, 20, 30], {20, 30}, 3))
