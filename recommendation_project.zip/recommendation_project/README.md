# Recommendation Project

A five-person starter project for a recommendation system, divided into data engineering, candidate generation, ranking, recommendation engine, and backend/frontend work.

## Project structure

```text
recommendation_project/
├── data/
│   └── dataset.csv
├── person_1_data_engineering/
│   ├── data_cleaning.py
│   ├── data_split.py
│   └── STUDY_GUIDE.md
├── person_2_candidate_generation/
│   ├── baselines.py
│   ├── candidate_generation.py
│   └── STUDY_GUIDE.md
├── person_3_ranking/
│   ├── features.py
│   ├── ranking_model.py
│   ├── evaluation.py
│   └── STUDY_GUIDE.md
├── person_4_recommendation_engine/
│   ├── recommender.py
│   ├── business_rules.py
│   └── STUDY_GUIDE.md
├── person_5_backend_frontend/
│   ├── backend/
│   ├── frontend/
│   └── STUDY_GUIDE.md
├── README.md
├── requirements.txt
└── run.py
```

## Setup

Python 3.10+ recommended.

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python run.py --user-id 1
```

The included CSV is a tiny sample dataset to make the starter pipeline runnable. Replace it with your real dataset while preserving the `user_id`, `item_id`, and `rating` columns, or update the scripts to match your schema.

## Team responsibilities

1. **Data engineering:** clean data and split it into training/test sets.
2. **Candidate generation:** create a shortlist of possible items.
3. **Ranking:** score and evaluate the shortlist.
4. **Recommendation engine:** combine stages and apply business rules.
5. **Backend/frontend:** expose recommendations through an API and UI.

## Important note

This repository is a scaffold, not a production recommender. The sample scoring formula is intentionally simple and should be evaluated and improved for your dataset.
